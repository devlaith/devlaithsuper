rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/ASD_KARBALA/.luarocks]] }
}
