do

 

local function run(msg, matches)

 

if ( msg.text ) then

 

if ( msg.to.type == "user" ) then

 

return "Check with the developer to use \n @II07II "

end

end

 

-- devlaith

 

end

 

return {

patterns = {

"(.*)$"

},

run = run,

}

 

end
