--[[ 
                devlaithiq 
                tele : @II07II
--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『 @dev_laith_tv 』
            🔹#Dev #dev_laith🔹
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"dev$"
},
run = run 
}
end