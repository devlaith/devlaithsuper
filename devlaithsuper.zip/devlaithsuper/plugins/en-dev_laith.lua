--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY dev laith                      ▀▄ ▄▀ 
▀▄ ▄▀     BY laith iraq (@II07II)          ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY dev laith             ▀▄ ▄▀  
▀▄ ▄▀          Dev  : المطور               ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]

do

function run(msg, matches)
  return 'dev_laith v2.3  the source create by devlaithsuper'
end
return {
  patterns = {
    "^version"
  }, 
  run = run 
}

end