--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY dev laith                      ▀▄ ▄▀ 
▀▄ ▄▀     BY laith iraq (@II07II)          ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY dev laith             ▀▄ ▄▀  
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

Bot, who works on the supergroups🔸

Bot to work on the super groups of up to 5 k Membe🔷

     ≪It has been making the bot by the developer≫
                      『 @II07II 』
            🔹#Dev #dev_laith🔹
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"dev1$"
},
run = run 
}
end