--[[ 
     Dev_laithiq 
     tele : @II07II
--]]

do

function run(msg, matches)
  return 'dev_laith v2.3  the source create by devlaithsuper'
end

return {
  patterns = {
    "^الاصدار"
  }, 
  run = run 
}

end