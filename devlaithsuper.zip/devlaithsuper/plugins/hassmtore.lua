do 

local function run(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

     return "🔚 المبرمج \n @II07II \n 🔚 للاستفسار \n @dev_laith_bot\n 🔚 قناتنا \n @dev_laith_tv "
     
  end 
   
end 

-- Matrix

end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = run, 
} 

end 
-- By @MuntadrMatrix